var swiper = new Swiper('.swiper1', {
        effect: 'fade',
        loop: true,
        pagination: '.swiper-pagination',
        paginationClickable: '.swiper-pagination',
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev'
//        breakpoints: {
//            767: {
//                effect: 'fade'
//            }
//        }
    });
    console.log('111111111111111111111111111111');